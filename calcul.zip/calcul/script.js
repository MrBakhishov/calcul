
//console.log("play");
let play = " ";
function hesab(say) {

    play += say;

    document.getElementById("play").value = play;

}
//document.getElementById{"hesab"}.inherhtml = eval(hesab1 + hesab2)

//function hesabla(){

//let  play = document.getElementById("play").value;
//let  opt  = document.getElementById("opt").value;
//let  play1 = document.getElementById("play1").value;

//document.getElementById{"ekran"}.inherhtml = eval(play + opt + play1)

//}